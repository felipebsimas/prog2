/* sempre ter no formulário no início action="" e no final method="post" ou "get" */

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>Seletor de cores</title>

</head>
<body>

<h2>Seletor de Cores Interativo</h2>

<form action="ap02ex02b.php" method="post">

<p>

<label for="inputName">R:<sup></sup></label>
<input type="text" name="r" id="number">

</p>
<p>

<label for="inputEmail">G:<sup></sup></label>
<input type="text" name="g" id="number">

</p>

<p>
<label for="inputSubject">B:</label>
<input type="text" name="b" id="inputSubject">


<input type="submit" value="Enviar">



</form>
</body>
</html>